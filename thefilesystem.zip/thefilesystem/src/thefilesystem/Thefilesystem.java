/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thefilesystem;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 *
 * @author Monitoring
 */
public class Thefilesystem {

    /**
     * @param args the command line arguments
     */
    public Thefilesystem(String filename) {
        String outfile = "C:\\Users\\Monitoring\\Documents\\NetBeansProjects\\thefilesystem\\src\\thefilesystem\\outputfile.txt";
        try {
            
            FileInputStream in = null;
            FileOutputStream out = null;
            in = new FileInputStream(filename);
            out = new FileOutputStream(outfile);
            int n;
            while ((n = in.read()) != -1) {
//               while((n=in.read(b, 1, 1))){  
                out.write(n);
                System.out.println(n);
            }
            in.close();
            System.out.println("File closed");
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

}
