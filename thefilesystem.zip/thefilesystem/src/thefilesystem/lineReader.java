/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thefilesystem;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author Monitoring
 */
public class lineReader {
    
    public lineReader(String filename){
        String outfile = "C:\\Users\\Monitoring\\Documents\\NetBeansProjects\\thefilesystem\\src\\thefilesystem\\outputfile.txt";
        try {
        BufferedReader br = null;
        PrintWriter pw = null;
        br = new BufferedReader(new FileReader(filename));
        pw = new PrintWriter(new FileWriter(outfile));
        
        String l;
        while((l = br.readLine()) != null){
            System.out.println(l);
          pw.write(l);
        }
        br.close();
        } catch(IOException e){
        
        }
    
    }
    
}
