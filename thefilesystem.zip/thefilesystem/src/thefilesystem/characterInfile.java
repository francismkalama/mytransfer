/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thefilesystem;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author Monitoring
 */
public class characterInfile {
    
    public characterInfile(String filename){
         String outfile = "C:\\Users\\Monitoring\\Documents\\NetBeansProjects\\thefilesystem\\src\\thefilesystem\\outputfile.txt";
        try {
            FileReader fr = null;
            FileWriter wr = null;
            fr = new FileReader(filename);
            wr = new FileWriter(outfile);
            int c;
            while((c=fr.read()) != -1){
                wr.write(outfile);
            }
            fr.close();
        }catch(IOException e){
            System.out.println();
        }
        }
    }
    

