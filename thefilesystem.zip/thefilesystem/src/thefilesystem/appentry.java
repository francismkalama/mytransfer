/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thefilesystem;

import java.io.FileInputStream;

/**
 *
 * @author Monitoring
 */
public class appentry {

    public static void main(String[] args) {
        // TODO code application logic here
        String filename = "C:\\Users\\Monitoring\\Documents\\NetBeansProjects\\thefilesystem\\src\\thefilesystem\\example.txt";

   //  Thefilesystem tfs = new Thefilesystem(filename);
   characterInfile cf = new characterInfile(filename);
//        lineReader lr = new lineReader(filename);
//        boolean mzeeStillAtPub=true;
//        while(mzeeStillAtPub){
//            try{  
//                System.out.println("Inafika");
//            Thread.sleep(1000);
//            
//          if(!mzeeStillAtPub){
//              System.out.println("hajafika");
//             break;
//           }
//            }catch (InterruptedException e){
//              System.out.println(e.getMessage());  ;
//    
//    }
//            
//        }
    }

}
